package com.insurance.insuranceCompany.repository;

public class DashBoardRepository {

}
