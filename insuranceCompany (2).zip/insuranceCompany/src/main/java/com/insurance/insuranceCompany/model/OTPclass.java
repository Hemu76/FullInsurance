package com.insurance.insuranceCompany.model;

public class OTPclass {
	private String otp;
	

    public String getOtp() {
        return otp;
    }

    public void setOtp(String otp) {
        this.otp = otp;
    }

}
